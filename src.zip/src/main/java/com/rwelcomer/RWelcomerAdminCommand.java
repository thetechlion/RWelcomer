package com.rwelcomer;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RWelcomerAdminCommand implements CommandExecutor {

    private final RWelcomerPlugin plugin;

    public RWelcomerAdminCommand(RWelcomerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("rwelcomer.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to do that.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /rwelcomer <sethub|reload>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "sethub" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only a player can set the hub (stand where you want it first).");
                    return true;
                }
                var loc = player.getLocation();
                plugin.getConfig().set("hub.world", loc.getWorld().getName());
                plugin.getConfig().set("hub.x", loc.getX());
                plugin.getConfig().set("hub.y", loc.getY());
                plugin.getConfig().set("hub.z", loc.getZ());
                plugin.getConfig().set("hub.yaw", loc.getYaw());
                plugin.getConfig().set("hub.pitch", loc.getPitch());
                plugin.saveConfig();
                sender.sendMessage(ChatColor.GREEN + "Hub set to your current location.");
            }
            case "reload" -> {
                plugin.loadSettings();
                sender.sendMessage(ChatColor.GREEN + "RWelcomer config reloaded.");
            }
            default -> sender.sendMessage(ChatColor.YELLOW + "Usage: /rwelcomer <sethub|reload>");
        }
        return true;
    }
}
