package com.rwelcomer;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class WelcomeMenu {

    private final RWelcomerPlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public WelcomeMenu(RWelcomerPlugin plugin) {
        this.plugin = plugin;
    }

    /** Builds "<gradient:start:end>text</gradient>" as a Component. */
    public Component gradient(String text) {
        String tag = "<gradient:" + plugin.getGradientStart() + ":" + plugin.getGradientEnd() + ">" + text + "</gradient>";
        return mm.deserialize(tag);
    }

    public Inventory buildMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(new MainMenuHolder(), 27, gradient("Welcome!"));
        fillBorder(inv);

        ItemStack start = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = start.getItemMeta();
        meta.displayName(gradient("<bold>\u25B6 Start</bold>"));
        meta.lore(List.of(
                Component.text(""),
                Component.text("Hi there " + player.getName() + ","),
                Component.text("welcome to " + plugin.getServerName() + "!"),
                Component.text(""),
                Component.text("Click to continue \u2192")
        ));
        start.setItemMeta(meta);
        inv.setItem(13, start);

        return inv;
    }

    public Inventory buildOptionsMenu() {
        Inventory inv = Bukkit.createInventory(new OptionsMenuHolder(), 27, gradient("Where to?"));
        fillBorder(inv);

        inv.setItem(11, buildOption(Material.LODESTONE, "Spawn at Hub",
                "Teleport to the server hub."));
        inv.setItem(13, buildOption(Material.CLOCK, "Spawn at Previous Location",
                "Return to where you last logged off."));
        inv.setItem(15, buildOption(Material.ENDER_PEARL, "Spawn at Random Location",
                "Teleport somewhere random in the world."));

        return inv;
    }

    private ItemStack buildOption(Material material, String name, String loreLine) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(gradient(name));
        meta.lore(List.of(Component.text(loreLine)));
        item.setItemMeta(meta);
        return item;
    }

    private void fillBorder(Inventory inv) {
        ItemStack blue = pane(Material.LIGHT_BLUE_STAINED_GLASS_PANE);
        ItemStack green = pane(Material.LIME_STAINED_GLASS_PANE);

        for (int i = 0; i < inv.getSize(); i++) {
            boolean edge = i < 9 || i >= inv.getSize() - 9 || i % 9 == 0 || i % 9 == 8;
            if (edge) {
                inv.setItem(i, (i / 9 + i % 9) % 2 == 0 ? blue : green);
            }
        }
    }

    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.empty());
        item.setItemMeta(meta);
        return item;
    }

    public static class MainMenuHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    public static class OptionsMenuHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
