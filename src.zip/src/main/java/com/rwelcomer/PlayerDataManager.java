package com.rwelcomer;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.logging.Level;

public class PlayerDataManager {

    private final RWelcomerPlugin plugin;
    private final File file;
    private YamlConfiguration data;

    public PlayerDataManager(RWelcomerPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "playerdata.yml");
        load();
    }

    private void load() {
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.WARNING, "Could not create playerdata.yml", e);
            }
        }
        data = YamlConfiguration.loadConfiguration(file);
    }

    /** Saves the given location as this player's "previous location" for next time. */
    public void setPreviousLocation(UUID uuid, Location location) {
        String path = uuid.toString();
        data.set(path + ".world", location.getWorld().getName());
        data.set(path + ".x", location.getX());
        data.set(path + ".y", location.getY());
        data.set(path + ".z", location.getZ());
        data.set(path + ".yaw", location.getYaw());
        data.set(path + ".pitch", location.getPitch());
        saveAll();
    }

    /** Returns the stored previous location, or null if none is on record. */
    public Location getPreviousLocation(UUID uuid) {
        String path = uuid.toString();
        if (!data.contains(path)) {
            return null;
        }
        String worldName = data.getString(path + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        double x = data.getDouble(path + ".x");
        double y = data.getDouble(path + ".y");
        double z = data.getDouble(path + ".z");
        float yaw = (float) data.getDouble(path + ".yaw");
        float pitch = (float) data.getDouble(path + ".pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void saveAll() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Could not save playerdata.yml", e);
        }
    }
}
