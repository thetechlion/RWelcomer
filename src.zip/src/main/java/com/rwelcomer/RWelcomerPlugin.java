package com.rwelcomer;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class RWelcomerPlugin extends JavaPlugin {

    private PlayerDataManager playerDataManager;
    private String serverName;
    private String gradientStart;
    private String gradientEnd;
    private boolean openOnJoin;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();

        this.playerDataManager = new PlayerDataManager(this);

        Bukkit.getPluginManager().registerEvents(new WelcomeGuiListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerTrackingListener(this, playerDataManager), this);

        getCommand("welcome").setExecutor(new WelcomeCommand(this));
        getCommand("rwelcomer").setExecutor(new RWelcomerAdminCommand(this));

        getLogger().info("RWelcomer enabled.");
    }

    @Override
    public void onDisable() {
        if (playerDataManager != null) {
            playerDataManager.saveAll();
        }
    }

    public void loadSettings() {
        reloadConfig();
        this.serverName = getConfig().getString("server-name", "the server");
        this.gradientStart = getConfig().getString("gradient.start", "#00BFFF");
        this.gradientEnd = getConfig().getString("gradient.end", "#32CD32");
        this.openOnJoin = getConfig().getBoolean("open-on-join", true);
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public String getServerName() {
        return serverName;
    }

    public String getGradientStart() {
        return gradientStart;
    }

    public String getGradientEnd() {
        return gradientEnd;
    }

    public boolean isOpenOnJoin() {
        return openOnJoin;
    }
}
