package com.rwelcomer;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WelcomeCommand implements CommandExecutor {

    private final RWelcomerPlugin plugin;
    private final WelcomeMenu menu;

    public WelcomeCommand(RWelcomerPlugin plugin) {
        this.plugin = plugin;
        this.menu = new WelcomeMenu(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        player.openInventory(menu.buildMainMenu(player));
        return true;
    }
}
