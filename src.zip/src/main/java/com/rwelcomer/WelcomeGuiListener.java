package com.rwelcomer;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.Random;

public class WelcomeGuiListener implements Listener {

    private final RWelcomerPlugin plugin;
    private final WelcomeMenu menu;
    private final Random random = new Random();

    public WelcomeGuiListener(RWelcomerPlugin plugin) {
        this.plugin = plugin;
        this.menu = new WelcomeMenu(plugin);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!plugin.isOpenOnJoin()) return;
        Player player = event.getPlayer();
        // Delay a tick so the menu opens after the join process settles.
        Bukkit.getScheduler().runTaskLater(plugin, () -> player.openInventory(menu.buildMainMenu(player)), 20L);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (event.getInventory().getHolder() instanceof WelcomeMenu.MainMenuHolder) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null) return;
            player.openInventory(menu.buildOptionsMenu());
            return;
        }

        if (event.getInventory().getHolder() instanceof WelcomeMenu.OptionsMenuHolder) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null) return;

            Material clicked = event.getCurrentItem().getType();
            player.closeInventory();

            switch (clicked) {
                case LODESTONE -> teleportToHub(player);
                case CLOCK -> teleportToPrevious(player);
                case ENDER_PEARL -> teleportToRandom(player);
                default -> { /* border pane clicked, ignore */ }
            }
        }
    }

    private void teleportToHub(Player player) {
        String worldName = plugin.getConfig().getString("hub.world", "");
        if (worldName == null || worldName.isEmpty()) {
            player.sendMessage(Component.text("Hub hasn't been set yet - ask an admin to run /rwelcomer sethub."));
            return;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            player.sendMessage(Component.text("Hub world is not loaded. Contact an admin."));
            return;
        }
        Location hub = new Location(world,
                plugin.getConfig().getDouble("hub.x"),
                plugin.getConfig().getDouble("hub.y"),
                plugin.getConfig().getDouble("hub.z"),
                (float) plugin.getConfig().getDouble("hub.yaw"),
                (float) plugin.getConfig().getDouble("hub.pitch"));
        player.teleport(hub);
        player.sendMessage(Component.text("Welcome to the hub!"));
    }

    private void teleportToPrevious(Player player) {
        Location previous = plugin.getPlayerDataManager().getPreviousLocation(player.getUniqueId());
        if (previous == null) {
            player.sendMessage(Component.text("No previous location on record - sending you to the hub instead."));
            teleportToHub(player);
            return;
        }
        player.teleport(previous);
        player.sendMessage(Component.text("Welcome back!"));
    }

    private void teleportToRandom(Player player) {
        String worldName = plugin.getConfig().getString("random-teleport.world", "");
        World world = (worldName == null || worldName.isEmpty()) ? player.getWorld() : Bukkit.getWorld(worldName);
        if (world == null) world = player.getWorld();

        int centerX = plugin.getConfig().getInt("random-teleport.center-x", 0);
        int centerZ = plugin.getConfig().getInt("random-teleport.center-z", 0);
        int radius = plugin.getConfig().getInt("random-teleport.radius", 2000);

        Location safe = findSafeLocation(world, centerX, centerZ, radius);
        if (safe == null) {
            player.sendMessage(Component.text("Couldn't find a safe spot - try again in a moment."));
            return;
        }
        player.teleport(safe);
        player.sendMessage(Component.text("Off you go!"));
    }

    private Location findSafeLocation(World world, int centerX, int centerZ, int radius) {
        for (int attempt = 0; attempt < 20; attempt++) {
            int x = centerX + random.nextInt(radius * 2) - radius;
            int z = centerZ + random.nextInt(radius * 2) - radius;
            int y = world.getHighestBlockYAt(x, z);
            Material ground = world.getBlockAt(x, y, z).getType();
            if (ground == Material.WATER || ground == Material.LAVA) {
                continue;
            }
            return new Location(world, x + 0.5, y + 1, z + 0.5);
        }
        return null;
    }
}
