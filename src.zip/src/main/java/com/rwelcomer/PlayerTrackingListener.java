package com.rwelcomer;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerTrackingListener implements Listener {

    private final PlayerDataManager playerDataManager;

    public PlayerTrackingListener(RWelcomerPlugin plugin, PlayerDataManager playerDataManager) {
        this.playerDataManager = playerDataManager;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        playerDataManager.setPreviousLocation(event.getPlayer().getUniqueId(), event.getPlayer().getLocation());
    }
}
